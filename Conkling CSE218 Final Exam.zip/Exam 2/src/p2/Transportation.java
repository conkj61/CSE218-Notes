package p2;

public abstract class Transportation {
	private String id;

	public Transportation(String id) {
		super();
		this.id = id;
	}
	
}

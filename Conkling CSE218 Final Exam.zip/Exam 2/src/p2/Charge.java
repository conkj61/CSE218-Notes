package p2;

import java.util.function.Function;

public class Charge<R> {

	public <T> void charge(Function<T, R> price) {
//		public R apply(T x);
//		public R apply(T x);
	}
	
}
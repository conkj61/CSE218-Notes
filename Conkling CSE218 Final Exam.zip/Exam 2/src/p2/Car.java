package p2;

public class Car extends Transportation {

	public Car(String id) {
		super(id);
	}

}

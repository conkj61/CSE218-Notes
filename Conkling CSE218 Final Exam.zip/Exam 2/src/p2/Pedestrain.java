package p2;

public class Pedestrain extends Transportation {

	public Pedestrain(String id) {
		super(id);
	}

}

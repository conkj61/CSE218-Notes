package p2;

public class Truck extends Transportation {

	public Truck(String id) {
		super(id);
	}

}

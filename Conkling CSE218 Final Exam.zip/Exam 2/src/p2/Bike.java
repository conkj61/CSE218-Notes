package p2;

public class Bike extends Transportation {

	public Bike(String id) {
		super(id);
	}

}
